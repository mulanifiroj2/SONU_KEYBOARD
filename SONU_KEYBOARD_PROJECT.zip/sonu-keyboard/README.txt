SONU Keyboard Android IME project

Build:
  gradle assembleDebug

GitHub Actions:
  Upload all project files to the root of a GitHub repository. The workflow at
  .github/workflows/build.yml builds app-debug.apk and uploads it as an artifact.

Install:
  Download the APK artifact from the completed Actions run, install it, then
  Android Settings > System settings > Keyboard & input method > Manage keyboards
  enable SONU Keyboard and select it as default.

Privacy:
  This first build requests no Internet permission and does not collect or transmit text.

This is a first functional starter. The existing HTML keyboard's exact adjustable SIZE panel,
full key arrangement, and full modifier behavior are not yet ported; this native IME starter
provides a system-wide keyboard foundation.
