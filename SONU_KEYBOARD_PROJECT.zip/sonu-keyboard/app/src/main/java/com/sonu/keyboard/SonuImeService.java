package com.sonu.keyboard;

import android.inputmethodservice.InputMethodService;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputConnection;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class SonuImeService extends InputMethodService {
    private boolean shift = false, caps = false, more = false;
    private LinearLayout root;
    private int bg = Color.rgb(16,21,29), keyBg = Color.rgb(38,53,72), accent = Color.rgb(8,125,105);

    @Override public View onCreateInputView() { buildKeyboard(); return root; }

    private void buildKeyboard() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(4,8,4,8); root.setBackgroundColor(bg);
        if (more) {
            addRow(new String[]{"←","→","↑","↓","HOME","END","DEL","ESC"});
            addRow(new String[]{"F1","F2","F3","F4","F5","F6","F7","F8","F9","F10","F11","F12"});
            addRow(new String[]{"CTRL+A","CTRL+C","CTRL+V","CTRL+X","CTRL+Z","CTRL+Y","BACK"});
        }
        addRow(new String[]{"1","2","3","4","5","6","7","8","9","0","BKSP"});
        addRow(new String[]{"Q","W","E","R","T","Y","U","I","O","P"});
        addRow(new String[]{"A","S","D","F","G","H","J","K","L"});
        addRow(new String[]{"SHIFT","Z","X","C","V","B","N","M",",",".","?"});
        addRow(new String[]{"?123","CAPS","CTRL","SPACE","ENTER","MORE"});
    }

    private void addRow(String[] keys) {
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER); 
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(49)); rp.bottomMargin = dp(4); root.addView(row, rp);
        for (String key : keys) {
            Button b = new Button(this); String label = display(key); b.setText(label); b.setTextColor(Color.WHITE); b.setTextSize(key.length()>4?10:14); b.setAllCaps(false); b.setTypeface(Typeface.DEFAULT, Typeface.BOLD); b.setPadding(0,0,0,0);
            GradientDrawable shape = new GradientDrawable(); shape.setColor(isActive(key)?accent:keyBg); shape.setCornerRadius(dp(6)); shape.setStroke(dp(1), Color.rgb(82,100,122)); b.setBackground(shape);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0,-1, weight(key)); p.setMargins(dp(2),0,dp(2),0); row.addView(b,p);
            b.setOnClickListener(v -> handle(key));
        }
    }
    private float weight(String k) { if(k.equals("SPACE")) return 4.2f; if(k.equals("SHIFT")||k.equals("ENTER")||k.equals("BKSP")||k.equals("?123")||k.equals("MORE")) return 1.5f; return 1f; }
    private boolean isActive(String k) { return (k.equals("SHIFT")&&shift)||(k.equals("CAPS")&&caps); }
    private String display(String k) {
        if(k.equals("SPACE")) return "SONU";
        if(k.equals("ENTER")) return "↵";
        if(k.equals("BKSP")) return "⌫";
        if(k.equals("MORE")) return more?"LESS":"MORE";
        if(k.equals("SHIFT")) return "⇧";
        if(k.equals("?123")) return "123";
        if(k.length()==1 && Character.isLetter(k.charAt(0))) return (shift||caps)?k:k.toLowerCase();
        if(shift) { String s="1234567890"; String t="!@#$%^&*()"; int i=s.indexOf(k); if(i>=0)return String.valueOf(t.charAt(i)); }
        return k;
    }
    private void handle(String k) {
        InputConnection ic = getCurrentInputConnection(); if(k.equals("SHIFT")){shift=!shift; refresh();return;} if(k.equals("CAPS")){caps=!caps;refresh();return;}
        if(k.equals("MORE")){more=!more;refresh();return;} if(k.equals("BACK")){more=false;refresh();return;}
        if(k.equals("CTRL")){return;} if(k.equals("?123")){shift=!shift;refresh();return;}
        if(ic==null)return;
        switch(k){case "SPACE": ic.commitText(" ",1); break; case "ENTER": ic.commitText("\n",1); break; case "BKSP": ic.deleteSurroundingText(1,0); break;
            case "←": ic.sendKeyEvent(new android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN,android.view.KeyEvent.KEYCODE_DPAD_LEFT)); break;
            case "→": ic.sendKeyEvent(new android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN,android.view.KeyEvent.KEYCODE_DPAD_RIGHT)); break;
            case "↑": ic.sendKeyEvent(new android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN,android.view.KeyEvent.KEYCODE_DPAD_UP)); break;
            case "↓": ic.sendKeyEvent(new android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN,android.view.KeyEvent.KEYCODE_DPAD_DOWN)); break;
            case "HOME": ic.sendKeyEvent(new android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN,android.view.KeyEvent.KEYCODE_MOVE_HOME)); break;
            case "END": ic.sendKeyEvent(new android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN,android.view.KeyEvent.KEYCODE_MOVE_END)); break;
            case "DEL": ic.sendKeyEvent(new android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN,android.view.KeyEvent.KEYCODE_FORWARD_DEL)); break;
            case "ESC": break;
            default:
                if(k.startsWith("CTRL+")){String c=k.substring(5); if(c.equals("A"))ic.performContextMenuAction(android.R.id.selectAll); else if(c.equals("C"))ic.performContextMenuAction(android.R.id.copy); else if(c.equals("V"))ic.performContextMenuAction(android.R.id.paste); else if(c.equals("X"))ic.performContextMenuAction(android.R.id.cut); return;}
                if(k.length()==1){String out=k; if(Character.isLetter(k.charAt(0)))out=(shift||caps)?k:k.toLowerCase(); else if(shift){String s="1234567890-=[]\\;',./";String t="!@#$%^&*()_+{}|:\"<>?";int i=s.indexOf(k);if(i>=0&&i<t.length())out=String.valueOf(t.charAt(i));} ic.commitText(out,1); if(shift){shift=false;refresh();}}
        }
    }
    private void refresh(){ if(root!=null)buildKeyboard(); }
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
}
